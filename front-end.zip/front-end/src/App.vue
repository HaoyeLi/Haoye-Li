<script setup>
import 'amfe-flexible'
</script>
<template>
    <router-view></router-view>
</template>
