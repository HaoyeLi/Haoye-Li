<script setup>
// 添加onmounted和dayjs
import { onMounted, ref, onUnmounted } from 'vue'
import { computed } from 'vue';
import PageHeader from '@components/PageHeader.vue'
import PageFooter from '@components/PageFooter.vue'

import axios from 'axios';
import { useStore } from 'vuex';
const store = useStore();
const socket = computed(() => store.getters.getSocket);
// 示例数据集，可以根据需要进行扩展
const dataSets = ref([
    {
        items: [
            { name: '血糖', value: 18.9, unit: 'mg/dL', 'abnormal': false },
            { name: '氯离子', value: 102.0, unit: 'mEq/L', 'abnormal': false },
            { name: '钾', value: 4.5, unit: 'mEq/L', 'abnormal': true },
            { name: '纳', value: 104.67, unit: 'mEq/L', 'abnormal': false },
            { name: '血红蛋白', value: 10.9, unit: 'g/dl', 'abnormal': false },
        ],
        charttime: '2023-03-01 08:00:00',
        suggestions_insulin: '建议低血糖饮食',
        suggestions_phenylephrine: '建议低血糖饮食',
    },
    {
        items: [
            { name: '血糖', value: 18.9, unit: 'mg/dL', 'abnormal': false },
            { name: '氯离子', value: 102.0, unit: 'mEq/L', 'abnormal': false },
            { name: '钾', value: 4.5, unit: 'mEq/L', 'abnormal': true },
            { name: '纳', value: 104.67, unit: 'mEq/L', 'abnormal': false },
            { name: '血红蛋白', value: 10.9, unit: 'g/dl', 'abnormal': false },
        ],
        charttime: '2023-03-01 08:00:00',
        suggestions_insulin: '建议低血糖饮食',
        suggestions_phenylephrine: '建议低血糖饮食',
    },
    {
        items: [
            { name: '血糖', value: 18.9, unit: 'mg/dL', 'abnormal': false },
            { name: '氯离子', value: 102.0, unit: 'mEq/L', 'abnormal': false },
            { name: '钾', value: 4.5, unit: 'mEq/L', 'abnormal': true },
            { name: '纳', value: 104.67, unit: 'mEq/L', 'abnormal': false },
            { name: '血红蛋白', value: 10.9, unit: 'g/dl', 'abnormal': false },
        ],
        charttime: '2023-03-01 08:00:00',
        suggestions_insulin: '建议低血糖饮食',
        suggestions_phenylephrine: '建议低血糖饮食',
    },
    // {
    //     items: [
    //         { name: '血糖', value: 18.9, unit: 'mg/dL', 'abnormal': false, normalRange: [0, 1] },
    //         { name: '氯离子', value: 102.0, unit: 'mEq/L', 'abnormal': false, normalRange: [0, 1] },
    //         { name: '钾', value: 4.5, unit: 'mEq/L', 'abnormal': true, normalRange: [0, 1] },
    //         { name: '纳', value: 104.67, unit: 'mEq/L', 'abnormal': false, normalRange: [0, 1] },
    //         { name: '血红蛋白', value: 10.9, unit: 'g/dl', 'abnormal': false, normalRange: [0, 1] },
    //     ],
    //     charttime: '2023-03-01 08:00:00',
    //     suggestions_insulin: '建议低血糖饮食',
    //     suggestions_phenylephrine: '建议低血糖饮食',

    // },
]);
function syncScroll(event) {
    const target = event.target;
    // 这里的逻辑是使得所有滚动的容器都同步到触发滚动事件的那一个的滚动位置
    if (container.value) {
        const otherContainers = document.querySelectorAll('.content');
        otherContainers.forEach((elem) => {
            if (elem !== target) {
                elem.scrollTop = target.scrollTop;
                elem.scrollLeft = target.scrollLeft;
            }
        });
    }
}
async function sendmychoice(mychoice, index, charttime) {
    try {
        const response = await axios.post('http://localhost:5000/mychoice', {
            mychoice: mychoice,
            index: index,
            charttime: charttime
        });

        // 在这里可以处理响应，比如更新数据集等操作
        console.log('Response:', response.data);

    } catch (error) {
        console.error('Error:', error);
    }
}
onMounted(async () => {
    if (container.value) {
        container.value.addEventListener('scroll', syncScroll);
    }
    socket.value.on('laboratory_results', data => {
        dataSets.value.push(data);
    });
});
onUnmounted(() => {
    if (container.value) {
        container.value.removeEventListener('scroll', syncScroll);
    }
});
</script>
<template>
    <div class="homepage">
        <PageHeader @changeMenu="handleActiveMenuChange" />
        <div>
            <div class="homeTitle" style="display: inline-block; width: 50%;">实验室检验</div>
            <div class="homeTitle" style="display: inline-block; width: 50%;">建议操作</div>
        </div>
        <div class="container" ref="container">
            <div class="group" v-for="(dataSet, index) in dataSets" :key="'group-' + index">
                <div class="left">
                    <div class="twoRfourOne threeCssX">
                        <span>检验指标</span>
                        <span>值</span>
                        <span>单位</span>
                        <span>是否异常</span>
                    </div>
                    <div ref="twoRfourTwo" class="twoRfourTwo threeCssX">
                        <li v-for="(item, itemIndex) in dataSet.items" :key="'item-' + index + '-' + itemIndex">
                            <span>{{ item.name }}</span>
                            <span>{{ item.value }}</span>
                            <span>{{ item.unit }}</span>
                            <span>{{ item.abnormal ? '异常' : '' }}</span>
                        </li>
                    </div>
                    <div class="linexBottom"><span></span><span></span></div>
                    <div class="content-top-right"></div>
                </div>
                <div class="w-[9px]"></div>
                <div class="right">
                    <div class="twoRfourOne threeCssX">{{ dataSet.charttime }}</div>
                    <div v-if="dataSet.suggestions_insulin">
                        <div class="twoRfourOne threeCssX">{{ dataSet.suggestions_insulin }}</div>
                        <div class="content-buttons">
                            <button class="button" @click="sendmychoice(0, 1, dataSet.charttime)">偏高</button>
                            <button class="button" @click="sendmychoice(1, 1, dataSet.charttime)">采纳</button>
                            <button class="button" @click="sendmychoice(2, 1, dataSet.charttime)">偏低</button>
                        </div>
                    </div>
                    <div v-if="dataSet.suggestions_phenylephrine">
                        <div class="twoRfourOne threeCssX">{{ dataSet.suggestions_phenylephrine }}</div>
                        <div class="content-buttons">
                            <button class="button" @click="sendmychoice(0, 2, dataSet.charttime)">偏高</button>
                            <button class="button" @click="sendmychoice(1, 2, dataSet.charttime)">采纳</button>
                            <button class="button" @click="sendmychoice(2, 2, dataSet.charttime)">偏低</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <PageFooter />
    </div>
</template>
<style scoped lang="less">
.homepage {
    width: 100%;
    height: 100vh;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    background-image: url('@assets/images/twoBg.3518e20f.png');
    background-position: -30px -40px;
    background-repeat: no-repeat;
    background-size: 120% 120%;
    color: white;
    padding: 0 20px;

    .threeRtwo {
        padding: 10px;
        border: 1px solid #406277;
        width: 1000px;
        height: 800px;
    }

    .twoTitle {
        color: #66E1DF;
        font-size: 30px;
        text-align: center;
        font-family: siyuan !important;
        height: 35px;
        line-height: 35px;
        display: flex;
        justify-content: space-around;
        font-weight: 700;

        div {
            font-family: siyuanBold !important;
        }
    }

    .container {
        display: flex;
        flex-direction: column;
        overflow: auto;
        scrollbar-color: #66E1DF rgba(4, 9, 20, .10);
        max-width: 2000px;

        .left {

            background: rgba(4, 9, 20, .90);
            background-repeat: no-repeat;
            background-size: contain;
            width: 50%;
            box-sizing: border-box;
            height: auto;
            overflow: hidden;
            padding: 15px;
        }

        .right {

            background: rgba(4, 9, 20, .90);
            background-repeat: no-repeat;
            background-size: contain;
            width: 50%;
            box-sizing: border-box;
        }
    }

    .group {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        box-sizing: border-box;
    }

    .container::-webkit-scrollbar {
        width: 10px;
    }

    .container::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

    .container::-webkit-scrollbar-thumb {
        background: blue;
    }

    .container::-webkit-scrollbar-thumb:hover {
        background: #555;
    }

    .button {
        background-color: #687691;
        border-color: #687691;
        color: #000000;
        border-radius: 5px;
        padding: 10px;
        margin-left: 30px;
        margin-right: 30px;
        cursor: pointer;
        transition: background-color 0.3s, border-color 0.3s, color 0.3s;
        font-size: 15px;
    }

    .button:hover {
        background-color: #73efff;
        border-color: #73efff;
    }

    .button-selected {
        background-color: #73efff;
        border-color: #73efff;
    }

    .content-text {
        align-items: center;
        justify-content: center;
        padding: 10px;
    }

    .diagnosistitle {
        font-size: 30px;
        margin-bottom: 20px;
    }

    .scrolling-text {
        overflow-y: auto;
        /* 显示滚动条 */
        max-height: 700px;
        /* 占据可用的剩余空间 */
        display: flex;
    }

    .content-buttons {
        margin-top: 0;
        flex: 1;
        /* 占总高度的十分之一 */
        display: flex;
        padding: 10px;
    }

    .content-buttons .button {
        margin-top: 0;
        flex-basis: 50%;
        /* 平分宽度 */
        text-align: center;
    }

    // #totalFlowRate {
    //     width: 10vw;
    //     height: 8vh;
    // }
}

.stats {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    padding: 10px 20px 10px 20px;

    p {
        color: #00e8e2;
        font-weight: 700;
        font-size: 20px;
        height: 30px;
    }
}

.twoRfour {
    background: rgba(52, 52, 52, .30);
    height: auto;
    overflow: hidden;
    padding: 15px;
    position: relative;
    margin-top: 10px;
    width: 100%;
}

.twoRfourOne {
    display: flex;
    justify-content: space-around;
    color: #64DDDB;
    height: 45px;
    line-height: 45px;
    font-size: 15px;
}

.twoRfourTwo {
    height: 200px;
    overflow-y: auto;
}

.twoRfourTwo li {
    list-style: none;
    display: flex;
    justify-content: space-around;
    color: #C6D3E1;
    font-family: siyuanLight !important;
    font-size: 14px;
    height: 40px;
    line-height: 40px;
}

.twoRfourTwo li:nth-child(odd) {
    background: #1F262B
}

.threeCssX {
    text-align: left;
}

.threeCssX span,
.threeCssX li span {
    display: inline-block;
    width: 20%;
}

.threeCssX span:nth-child(1) {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.threeCssX li {
    padding: 0px 10px;
}

.homeTitle {
    background: url(../../assets/images/title_bg.38371a5b.png) no-repeat 0;
    background-size: 90% 100%;
    height: 46px;
    line-height: 46px;
    text-indent: 40px;
    color: #2dd3d3;
    font-size: 22px;
    font-weight: 700;
    text-align: center;
    font-family: siyuanMedium !important;
}
</style>
