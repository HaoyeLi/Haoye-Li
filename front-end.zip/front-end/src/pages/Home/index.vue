<script setup>
// 添加onmounted和dayjs
import { onMounted, ref } from 'vue'
import { computed } from 'vue';
import PageHeader from '@components/PageHeader.vue'
import PageFooter from '@components/PageFooter.vue'
import axios from 'axios';
import * as echarts from "echarts";
import { useStore } from 'vuex';
const store = useStore();
const socket = computed(() => store.getters.getSocket);
const stats = ref({
    spo2: 0,
    resp_rate: 0,
    temperature: 0,
    bp_mean: 0,
    bp_sys: 0,
    bp_dia: 0,
    heart_rate: 0,
});
const icustay_id = ref('');
const age = ref('');
const gender = ref('');
const height = ref('');
const weight = ref('');
const conditions_to_display = ref([]);
const diagnosis_to_display = ref([]);
const showUnderlying = ref(true); // 默认显示基础疾病
const showDiagnosis = ref(false);
const showContent = (type) => {
    if (type === 'underlying') {
        showUnderlying.value = true;
        showDiagnosis.value = false;
    } else if (type === 'diagnosis') {
        showUnderlying.value = false;
        showDiagnosis.value = true;
    }
};
onMounted(async () => {
    flowRate();
    try {
        // Send request to backend to fetch data
        const response = await axios.post('http://localhost:5000/get_patient_data');
        const data = response.data;
        // Update data
        icustay_id.value = data.icustay_id;
        age.value = data.age;
        gender.value = data.gender;
        height.value = data.height;
        weight.value = data.weight;
        conditions_to_display.value = data.conditions_to_display;
        diagnosis_to_display.value = data.diagnosis_to_display;
    } catch (error) {
        console.error('Error fetching data:', error);
    };
    socket.value.on('temperature', data => {
        stats.value.temperature = data.temperature;
    });
    socket.value.on('spo2', data => {
        stats.value.spo2 = data.spo2;
    });
    socket.value.on('resp_rate', data => {
        stats.value.resp_rate = data.resp_rate;
    });
    socket.value.on('bp_sys', data => {
        stats.value.bp_sys = data.bp_sys;
    })
    socket.value.on('bp_dia', data => {
        stats.value.bp_dia = data.bp_dia;
    })
    socket.value.on('bp_mean', data => {
        stats.value.bp_mean = data.bp_mean;
    })
});
function flowRate() {
    var xAxisData = [];
    var yAxisData = [];
    for (var i = 60; i > 0; i--) {
        xAxisData.push(i + "秒前");
    }
    for (i = 1; i < 61; i++) {
        yAxisData.push(null);
    }
    var myChart = echarts.init(document.getElementById("totalFlowRate"));
    let option = {
        animation: false,
        color: "#00E4E0",

        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'cross' }
        },
        grid: {
            left: 60/*"50px"*/,
            bottom: 20,
            right: 15/*"15px"*/
        },
        legend: {
            data: ['当前心率'],
            orient: "horizontal",
            top: '5%',
            right: '20px',
            textStyle: {
                color: "#B8C4D2",
                fontSize: "15px",
            }
        },
        xAxis: {
            boundaryGap: false,
            data: xAxisData,
        },
        yAxis: {
            boundaryGap: false,
            splitLine: {
                show: false,
            },
        },
        series: {
            symbol: "none",
            name: '当前心率',
            type: 'line',
            data: yAxisData,
        }
    }
    myChart.setOption(option);
    // setInterval(function () {
    //     yAxisData.push(Math.round(Math.random() * 50 + 50));
    //     if (yAxisData.length > 50) {
    //         yAxisData.shift();
    //     }
    //     myChart.setOption(option);
    // }, 100);
    // 更新 echarts 图表数据的函数
    socket.value.on('heart_rate', data => {
        // 更新数据
        console.log('Received heart rate:', data.value);
        stats.value.heart_rate = data.value;
        yAxisData.push(data.value); // 假设收到的数据在 'value' 字段中
        if (yAxisData.length > 60) {
            yAxisData.shift();
        }
        // 更新图表
        myChart.setOption(option);

    });
};
</script>
<template>
    <div class="homepage">
        <PageHeader @changeMenu="handleActiveMenuChange" />
        <div class="content flex-1 flex">
            <div class="left" :style="{ backgroundImage: `url(${img1})`, }">
                <div class="twoTitle">
                    <div>典型患者病例档案</div>
                </div>
                <div class="patient">
                    <div class="image imagepara">
                        <img src="@assets\images\touxiang.png" alt="Image">
                    </div>
                    <div class="stats">
                        <div>患者ID：{{ icustay_id }}</div>
                        <div>年龄：{{ age }}</div>
                        <div>性别：{{ gender }}</div>
                        <div>身高：{{ height }}</div>
                        <div>体重：{{ weight }}</div>
                    </div>
                </div>
                <div class="content-top-right">
                </div>
                <div class="content-buttons">
                    <button class="button" @click="showContent('underlying')">基础疾病</button>
                    <button class="button" @click="showContent('diagnosis')">诊断疾病</button>
                </div>
                <div class="scrolling-text">
                    <div v-show="showUnderlying" id="underlyingContent">
                        <div>基础疾病：</div>
                        <div v-for="condition in conditions_to_display" :key="condition">{{ condition }}</div>
                    </div>
                    <div v-show="showDiagnosis" id="diagnosisContent">
                        <div>诊断信息：</div>
                        <div v-for="diagnosis in diagnosis_to_display" :key="diagnosis.seq_num">
                            <div>序号: {{ diagnosis.seq_num }}, ICD9代码: {{ diagnosis.icd9_code }}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="w-[9px]"></div>
            <div class="middle">
                <div id="totalFlowRate" class="threeRtwo"></div>
            </div>
            <div class="w-[9px]"></div>
            <div class="right">
                <div class="chuangkou">
                    <p>
                    <div style="width: 50px;">
                        <div style="font-size: 20px; color:red;">ECG</div>
                        <div style="font-size: 20px; color:red;">bpm</div>
                    </div>
                    <div style="font-size: 100px; color:red;margin-left: 35px;">{{ stats.heart_rate }}</div>
                    </p>
                    <p>
                    <div style="width: 50px;">
                        <div style="font-size: 20px; color:green;">Spo2</div>
                        <div style="font-size: 20px; color:green;">%</div>
                    </div>
                    <div style="font-size: 100px; color:green;margin-left: 35px;">{{ stats.spo2 }}</div>
                    </p>
                    <div class="h-[5px]"></div>
                    <p style="flex-direction: column;">
                    <div style="width: 50px;">
                        <div style="font-size: 18px; color:bisque;white-space: nowrap;">NIBP mmHg </div>
                    </div>
                    <div style="font-size: 18px; color:bisque;margin-left: 20px;">Sys/Dia</div>
                    <div style="font-size: 60px; color:bisque;margin-left: 30px;height: fit-content;">{{ stats.bp_dia
                        }}/{{ stats.bp_sys }}
                    </div>
                    <div style="font-size: 20px; color:bisque;margin-left: 40px;">Mean（{{ stats.bp_mean }}）</div>

                    </p>
                    <div class="h-[5px]"></div>
                    <p>
                    <div style="width: 50px;">
                        <div style="font-size: 20px; color:bisque;">RR</div>
                        <div style="font-size: 20px; color:bisque;">rpm</div>
                    </div>
                    <div style="font-size: 100px; color:bisque;margin-left: 35px;">{{ stats.resp_rate }}</div>
                    </p>
                    <div class="h-[5px]"></div>
                    <p>
                    <div style="width: 50px;">
                        <div style="font-size: 20px; color:coral;">TEMP</div>
                        <div style="font-size: 20px; color:coral;">°C</div>
                    </div>
                    <div style="font-size: 100px; color:coral;margin-left: 35px;">{{ stats.temperature }}</div>
                    </p>
                    <!-- <p>平均压: {{ stats.bp_mean }}hhHg</p>
                    <p>舒张压: {{ stats.bp_dia }}hhHg</p>
                    <p>收缩压: {{ stats.bp_sys }}hhHg</p> -->
                </div>
            </div>
        </div>
        <PageFooter />
    </div>
</template>
<style scoped lang="less">
.homepage {
    width: 100%;
    height: 100vh;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    background-image: url('@assets/images/twoBg.3518e20f.png');
    background-position: -30px -40px;
    background-repeat: no-repeat;
    background-size: 120% 120%;
    color: white;
    padding: 0 20px;

    .threeRtwo {
        padding: 10px;
        border: 1px solid #406277;
        width: 100%;
        height: auto;
    }

    .twoTitle {
        color: #66E1DF;
        font-size: 35px;
        text-align: center;
        font-family: siyuan !important;
        height: 35px;
        line-height: 35px;
        display: flex;
        justify-content: space-around;
        font-weight: 700;
        margin-top: 50px;

        div {
            font-family: siyuanBold !important;
        }
    }

    .content {
        .active {
            background: #434343;
            border: 2px solid #73efff;
        }

        .left {
            position: relative;
            background-color: #040914;
            background-repeat: no-repeat;
            background-size: contain;
            flex: 5;
        }

        .middle {
            position: relative;
            background-color: #040914;
            background-repeat: no-repeat;
            background-size: contain;
            display: flex;
            flex: 6;
            flex-direction: row;
        }

        .right {
            position: relative;
            background-color: rgba(0, 0, 0, 0);
            background-repeat: no-repeat;
            background-size: contain;
            display: flex;
            flex: 2;
            flex-direction: row;
        }
    }

    .button {
        background-color: #687691;
        border-color: #687691;
        color: #0a1225;
        border-radius: 5px;
        padding: 10px;
        margin-left: 30px;
        margin-right: 30px;
        cursor: pointer;
        transition: background-color 0.3s, border-color 0.3s, color 0.3s;

    }

    .button:hover {
        background-color: #73efff;
        border-color: #73efff;
    }

    .button-selected {
        background-color: #73efff;
        border-color: #73efff;
    }

    .content-text {
        align-items: center;
        justify-content: center;
        padding: 10px;
    }

    .diagnosistitle {
        font-size: 30px;
        margin-bottom: 20px;
    }

    .scrolling-text {
        overflow-y: auto;
        /* 显示滚动条 */
        max-height: 700px;
        /* 占据可用的剩余空间 */
        display: flex;
        flex: auto;
        font-size: 20px;
        margin-left: 40px;


    }

    .content-buttons {
        margin-top: 0;
        flex: 1;
        /* 占总高度的十分之一 */
        display: flex;
    }

    .content-buttons .button {
        margin-top: 0;
        flex-basis: 50%;
        /* 平分宽度 */
        text-align: center;
        margin-bottom: 30px;
        font-size: 17px;
        font-weight: 700;
    }

    // #totalFlowRate {
    //     width: 10vw;
    //     height: 8vh;
    // }
}

.patient {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-top: 50px;
    margin-bottom: 30px;
}

.stats {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    padding: 10px 20px 10px 30px;
    width: 50%;

    div {
        color: #00e8e2;
        font-weight: 700;
        font-size: 20px;
        height: 30px;
    }
}

.image {
    width: 50%;
    display: flex;
    justify-content: center;
}

.image img {
    max-width: 50%;
    height: auto;
}

.chuangkou {
    width: 100%;
    display: flex;
    flex-direction: column;

    p {
        flex: 1;
        background-color: #040914;
        display: flex;
        text-align: center;
    }
}
</style>
