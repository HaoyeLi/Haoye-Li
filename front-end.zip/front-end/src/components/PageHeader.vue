<script setup>
import { ref, defineEmits } from 'vue'
import { useRouter, useRoute } from 'vue-router'
const emit = defineEmits(['changeMenu'])
const router = useRouter()
const route = useRoute()
const menuList = ref([
    {
        id: 'Home',
        label: '主页',
        path: '/Home',
    },
    {
        id: 'BloodSuger',
        label: '血糖',
        path: '/BloodSuger',
    },
    {
        id: 'Shock',
        label: '休克',
        path: '/Shock',
    },
    {
        id: 'Breath',
        label: '呼吸',
        path: '/Breath',
    },
])

const activeMenuId = ref()
const changeMenu = (menu, item) => {
    activeMenuId.value = item
    console.log(activeMenuId.value['id'])
    // 传递当前菜单栏点击按钮到任务界面组件 20240109_ptDoge
    emit('changeMenu', activeMenuId.value['id'])
    router.push(item.path || '#')
}
const navigateTo = (path) => {
    router.push(path);
}
</script>
<template>
    <div class="header">
        <div class="left">
            <img src="@assets/images/home/earth.png" alt="" />
            <span>ICU系统</span>
        </div>
        <div class="middle items-center">
            <el-button v-for="menu in menuList" :key="menu.id" class="dropdown-link select-none"
                :class="{ activeMenu: menu.path === route.path }" @click="navigateTo(menu.path)">
                {{ menu.label }}
            </el-button>
        </div>
        <div class="right">
            <!-- <i class="iconfont icon-tuichu !text-[32px] cursor-pointer"></i> -->
        </div>
    </div>
</template>
<style scoped lang="less">
.header {
    height: 76px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left {
        display: flex;
        align-items: center;

        img {
            width: 44px;
            height: 44px;
        }

        span {
            font-size: 26px;
            font-weight: 500;
            color: #ffffff;
            line-height: 23px;
            margin-left: 15px;
        }
    }

    .middle {
        display: flex;
        align-items: center;

        :deep(.el-button) {
            margin-right: 100px;
            /* 减小间距 */
            background-color: transparent;
            /* 设置背景为透明 */
            border: none;
            /* 移除边框 */
            padding: 0;
            font-size: 20px;

            .dropdown-link {
                font-weight: 500;
                color: #ffffff;
            }
        }
    }

    .right {
        display: flex;
        align-items: center;

        img {
            width: 28px;
            height: 32px;
            color: #edf6ff;
        }

        span {
            font-size: 18px;
            font-weight: 500;
            color: #ffffff;
            line-height: 21px;
            margin-right: 122px;
        }
    }
}
</style>
