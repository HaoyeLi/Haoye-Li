<script setup>
import { onMounted, ref } from 'vue'
import { computed } from 'vue';
const multiplier = ref(1);
const time = ref('');
import { useStore } from 'vuex';
const store = useStore();
const socket = computed(() => store.getters.getSocket);
onMounted(() => {
    socket.value.on('update_time', data => {
        // console.log('Received time update:', data.time);
        time.value = data.time;
    });
});
const setMultiplier = (value) => {
    multiplier.value = value;
    socket.value.emit('update_time_rate', { multiplier: value });
};
</script>
<template>
    <div class="footer text-[16px] text-white opacity-[0.59]">
        <div class="left">
            <span> 请选择时间倍率： </span>
            <button :class="{ 'multiplier-button-selected': multiplier === 1 }" class="multiplier-button"
                @click="setMultiplier(1)">X1</button>
            <button :class="{ 'multiplier-button-selected': multiplier === 10 }" class="multiplier-button"
                @click="setMultiplier(10)">X10</button>
            <button :class="{ 'multiplier-button-selected': multiplier === 60 }" class="multiplier-button"
                @click="setMultiplier(60)">X60</button>
            <button :class="{ 'multiplier-button-selected': multiplier === 300 }" class="multiplier-button"
                @click="setMultiplier(300)">X300</button>
        </div>
        <div class="right">
            <span>当前时间：</span><span>{{ time }}</span>
        </div>
    </div>
</template>
<style scoped lang="less">
.footer {
    height: 41px;
    display: flex;
    align-items: center;
    background: rgba(4, 9, 20, .90);
    font-weight: 700;
    font-size: 16px;

    .left {
        flex: 1;

        height: 27px;

        .multiplier-button {
            background-color: #687691;
            border-color: #687691;
            color: #000000;
            border-radius: 3px;
            padding: 5px 20px;
            margin-left: 100px;
            cursor: pointer;
            transition: background-color 0.3s, border-color 0.3s, color 0.3s;
            font-weight: 400;
        }

        .multiplier-button:hover {
            background-color: #73efff;
            border-color: #73efff;
        }

        .multiplier-button-selected {
            background-color: #73efff;
            border-color: #73efff;
        }
    }

    .right {
        user-select: none;
        flex: 1;
        align-items: center;
        display: flex;
        margin-left: 400px;
    }

}
</style>
