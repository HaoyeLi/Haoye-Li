import { createApp, h } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import 'reset-css'
import '@assets/css/main.less'
import '@assets/images/iconfont/iconfont.css'
import 'element-plus/dist/index.css'
import ElementPlus from 'element-plus'
import App from './App.vue'
import Home from '@pages/Home/index.vue'
import store from './store/socket';
const BloodSuger = () => import('@pages/BloodSuger/index.vue')
const Breath = () =>
    import('@pages/Breath/index.vue')
const Shock = () =>
    import('@pages/Shock/index.vue')
const routes = [
    {
        path: '/',
        component: App,
        redirect: '/Home',
        children: [
            { path: '/Home', component: Home },
            { path: '/BloodSuger', component: BloodSuger },
            {
                path: '/Breath',
                component: Breath,
            },
            {
                path: '/Shock',
                component: Shock,
            },
        ],
    },
]
const router = createRouter({
    history: createWebHashHistory(),
    routes,
})
const app = createApp({
    render: () => h(App),
})
app.use(ElementPlus)
app.use(router)
store.dispatch('initializeSocket');
app.use(store);
app.mount('#app')
