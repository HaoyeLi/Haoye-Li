import { io } from "socket.io-client";
import { createStore } from 'vuex';
const socket = io('http://' + location.hostname + ':' + location.port); // 这里是你的 Socket.IO 服务器地址

export default createStore({
    state: {
        socket: null
    },
    mutations: {
        setSocket(state, socketInstance) {
            state.socket = socketInstance;
        }
    },
    actions: {
        initializeSocket({ commit }) {
            commit('setSocket', socket);
        }
    },
    getters: {
        getSocket(state) {
            return state.socket;
        }
    }
});