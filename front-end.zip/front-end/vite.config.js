import { defineConfig } from 'vite'
import tailwindcss from 'tailwindcss'
import vue from '@vitejs/plugin-vue'
import pxtorem from 'postcss-pxtorem'

// https://vitejs.dev/config/
export default defineConfig({
    base: '/',
    plugins: [vue()],
    css: {
        postcss: {
            plugins: [
                tailwindcss({}),
                pxtorem({
                    rootValue: 192,
                    propList: ['*'],
                    unitPrecision: 6,
                }),
            ],
        },
    },
    resolve: {
        alias: {
            '@assets': '/src/assets',
            '@pages': '/src/pages',
            '@components': '/src/components',
        },
    },
})
