<script setup>
import { ref } from 'vue'
import PageHeader from '@components/PageHeader.vue'
import PageFooter from '@components/PageFooter.vue'

const img1 = ref(demoImg)
const img2 = ref(demoImg)
const active = ref('left')
</script>
<template>
    <div class="image-registration">
        <PageHeader />
        <div class="content flex-1 flex">
            <div class="left flex-1" :class="active === 'left' && 'active'" :style="{
                backgroundImage: `url(${img1})`,
            }">
                <OperationBtn class="img-btn" />
            </div>
            <div class="w-[9px]"></div>
            <div class="right flex-1" :class="active === 'right' && 'active'" :style="{
                backgroundImage: `url(${img2})`,
            }">
                <TaskSetting class="task-setting" />
            </div>
        </div>
        <PageFooter />
    </div>
</template>
<style scoped lang="less">
.image-registration {
    width: 100%;
    height: 100vh;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    background-position: -30px -40px;
    background-repeat: no-repeat;
    background-size: 120% 120%;
    color: white;
    padding: 0 20px;

    .content {
        .active {
            background: #434343;
            border: 2px solid #73efff;
        }

        .left {
            position: relative;
            background-color: #040914;
            background-repeat: no-repeat;
            background-size: contain;

            .process-btn {
                position: absolute;
                top: 50px;
                left: 5px;
            }

            .img-btn {
                position: absolute;
                left: 2px;
                top: 50%;
                transform: translateY(-50%);
            }
        }

        .right {
            position: relative;
            background-color: #040914;
            background-repeat: no-repeat;
            background-size: contain;

            .task-setting {
                position: absolute;
            }

            :deep(.task-setting__btn) {
                right: 4px;
                bottom: 43px;
            }
        }
    }
}
</style>
