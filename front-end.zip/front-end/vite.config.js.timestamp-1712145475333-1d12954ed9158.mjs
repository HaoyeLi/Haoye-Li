// vite.config.js
import { defineConfig } from "file:///D:/pythonAPP/medicine/front-end/node_modules/vite/dist/node/index.js";
import tailwindcss from "file:///D:/pythonAPP/medicine/front-end/node_modules/tailwindcss/lib/index.js";
import vue from "file:///D:/pythonAPP/medicine/front-end/node_modules/@vitejs/plugin-vue/dist/index.mjs";
import pxtorem from "file:///D:/pythonAPP/medicine/front-end/node_modules/postcss-pxtorem/index.js";
var vite_config_default = defineConfig({
  base: "/",
  plugins: [vue()],
  css: {
    postcss: {
      plugins: [
        tailwindcss({}),
        pxtorem({
          rootValue: 192,
          propList: ["*"],
          unitPrecision: 6
        })
      ]
    }
  },
  resolve: {
    alias: {
      "@assets": "/src/assets",
      "@pages": "/src/pages",
      "@components": "/src/components"
    }
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJEOlxcXFxweXRob25BUFBcXFxcbWVkaWNpbmVcXFxcZnJvbnQtZW5kXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ZpbGVuYW1lID0gXCJEOlxcXFxweXRob25BUFBcXFxcbWVkaWNpbmVcXFxcZnJvbnQtZW5kXFxcXHZpdGUuY29uZmlnLmpzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9EOi9weXRob25BUFAvbWVkaWNpbmUvZnJvbnQtZW5kL3ZpdGUuY29uZmlnLmpzXCI7aW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSdcclxuaW1wb3J0IHRhaWx3aW5kY3NzIGZyb20gJ3RhaWx3aW5kY3NzJ1xyXG5pbXBvcnQgdnVlIGZyb20gJ0B2aXRlanMvcGx1Z2luLXZ1ZSdcclxuaW1wb3J0IHB4dG9yZW0gZnJvbSAncG9zdGNzcy1weHRvcmVtJ1xyXG5cclxuLy8gaHR0cHM6Ly92aXRlanMuZGV2L2NvbmZpZy9cclxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcclxuICAgIGJhc2U6ICcvJyxcclxuICAgIHBsdWdpbnM6IFt2dWUoKV0sXHJcbiAgICBjc3M6IHtcclxuICAgICAgICBwb3N0Y3NzOiB7XHJcbiAgICAgICAgICAgIHBsdWdpbnM6IFtcclxuICAgICAgICAgICAgICAgIHRhaWx3aW5kY3NzKHt9KSxcclxuICAgICAgICAgICAgICAgIHB4dG9yZW0oe1xyXG4gICAgICAgICAgICAgICAgICAgIHJvb3RWYWx1ZTogMTkyLFxyXG4gICAgICAgICAgICAgICAgICAgIHByb3BMaXN0OiBbJyonXSxcclxuICAgICAgICAgICAgICAgICAgICB1bml0UHJlY2lzaW9uOiA2LFxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbiAgICByZXNvbHZlOiB7XHJcbiAgICAgICAgYWxpYXM6IHtcclxuICAgICAgICAgICAgJ0Bhc3NldHMnOiAnL3NyYy9hc3NldHMnLFxyXG4gICAgICAgICAgICAnQHBhZ2VzJzogJy9zcmMvcGFnZXMnLFxyXG4gICAgICAgICAgICAnQGNvbXBvbmVudHMnOiAnL3NyYy9jb21wb25lbnRzJyxcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxufSlcclxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUF1UixTQUFTLG9CQUFvQjtBQUNwVCxPQUFPLGlCQUFpQjtBQUN4QixPQUFPLFNBQVM7QUFDaEIsT0FBTyxhQUFhO0FBR3BCLElBQU8sc0JBQVEsYUFBYTtBQUFBLEVBQ3hCLE1BQU07QUFBQSxFQUNOLFNBQVMsQ0FBQyxJQUFJLENBQUM7QUFBQSxFQUNmLEtBQUs7QUFBQSxJQUNELFNBQVM7QUFBQSxNQUNMLFNBQVM7QUFBQSxRQUNMLFlBQVksQ0FBQyxDQUFDO0FBQUEsUUFDZCxRQUFRO0FBQUEsVUFDSixXQUFXO0FBQUEsVUFDWCxVQUFVLENBQUMsR0FBRztBQUFBLFVBQ2QsZUFBZTtBQUFBLFFBQ25CLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFBQSxFQUNBLFNBQVM7QUFBQSxJQUNMLE9BQU87QUFBQSxNQUNILFdBQVc7QUFBQSxNQUNYLFVBQVU7QUFBQSxNQUNWLGVBQWU7QUFBQSxJQUNuQjtBQUFBLEVBQ0o7QUFDSixDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
