/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ['./src/**/*.{html,vue,js}'],
    theme: {
        screen: {},
        extend: {},
    },
    plugins: [],
}
