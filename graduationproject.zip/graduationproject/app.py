from collections import deque
from random import randint
import random
from flask import Flask, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql.expression import func
from flask import Flask, render_template, request, jsonify
from flask import session
from flask import render_template
from flask_cors import CORS
from flask_socketio import SocketIO
from datetime import datetime, timedelta
import threading
import time

app = Flask(__name__, static_url_path="/")
app.secret_key = 'a1B2c3D4e5F6g7H8i9J0k!@#$%^&*'
app.config['SECRET_KEY'] = 'a1B2c3D4e5F6g7H8i9J0k!@#$%^&*'

# 配置静态文件夹，指向Vue的dist目录
app.static_folder = "..\\front-end\\dist"
app.template_folder = "..\\front-end\\dist"
socketio = SocketIO(app)
CORS(app, expose_headers='Content-Disposition')

HOSTNAME = "127.0.0.1"
PORT = 3306
USERNAME = "root"
PASSWORD = "2215617660"
DATABASE = "bloodsuger"
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4"

db = SQLAlchemy(app)
icustay_id = None

current_virtual_time = datetime(2024, 1, 1, 0, 0, 0)
time_rate = 1  # 初始速率为1，即正常速度
connectioned = False
emit_time_thread = None
thread_stop_event = threading.Event()  # Event to signal thread to stop
change_userid_flag = False
class Age(db.Model):
    __tablename__ = 'age(1)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    age = db.Column(db.Integer, nullable=False)

class Gender(db.Model):
    __tablename__ = 'gender(1)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    gender = db.Column(db.String(10), nullable=False)

class Height(db.Model):
    __tablename__ = 'height(1)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    
class Weight(db.Model):
    __tablename__ = 'weight(1)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Float, nullable=False)

class Calcium(db.Model):
    __tablename__ = 'calcium(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Albumin(db.Model):
    __tablename__ = 'albumin(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Hemoglobin(db.Model):
    __tablename__ = 'hemoglobin(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class WBC(db.Model):
    __tablename__ = 'wbc(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Glucose(db.Model):
    __tablename__ = 'glucose(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Chloride(db.Model):
    __tablename__ = 'chloride(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Potassium(db.Model):
    __tablename__ = 'potassium(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Sodium(db.Model):
    __tablename__ = 'sodium(2)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class InsulinCV(db.Model):
    __tablename__ = 'insulin_cv(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)

class PhenylephrineCV(db.Model):
    __tablename__ = 'phenylephrine_cv(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)

class UnderlyingCondition(db.Model):
    __tablename__ = 'underlying_condition(5)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    congestive_heart_failure = db.Column(db.Integer)
    cardiac_arrhythmias = db.Column(db.Integer)
    valvular_disease = db.Column(db.Integer)
    pulmonary_circulation = db.Column(db.Integer)
    peripheral_vascular = db.Column(db.Integer)
    hypertension = db.Column(db.Integer)
    paralysis = db.Column(db.Integer)
    other_neurological = db.Column(db.Integer)
    chronic_pulmonary = db.Column(db.Integer)
    diabetes_uncomplicated = db.Column(db.Integer)
    diabetes_complicated = db.Column(db.Integer)
    hypothyroidism = db.Column(db.Integer)
    renal_failure = db.Column(db.Integer)
    liver_disease = db.Column(db.Integer)
    peptic_ulcer = db.Column(db.Integer)
    aids = db.Column(db.Integer)
    lymphoma = db.Column(db.Integer)
    metastatic_cancer = db.Column(db.Integer)
    solid_tumor = db.Column(db.Integer)
    rheumatoid_arthritis = db.Column(db.Integer)
    coagulopathy = db.Column(db.Integer)
    obesity = db.Column(db.Integer)
    weight_loss = db.Column(db.Integer)
    fluid_electrolyte = db.Column(db.Integer)
    blood_loss_anemia = db.Column(db.Integer)
    deficiency_anemias = db.Column(db.Integer)
    alcohol_abuse = db.Column(db.Integer)
    drug_abuse = db.Column(db.Integer)
    psychoses = db.Column(db.Integer)
    depression = db.Column(db.Integer)

class DiagnosisCondition(db.Model):
    __tablename__ = 'diagnosis_condition(5)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    seq_num = db.Column(db.Integer, primary_key=True)
    icd9_code = db.Column(db.String)  # ICD-9编码
    
class D_Icd_Diagnoses(db.Model):
    __tablename__ = 'd_icd_diagnoses(5)'
    row_id = db.Column(db.Integer, primary_key=True)
    icd9_code = db.Column(db.String)
    short_title = db.Column(db.String)
    long_title = db.Column(db.String)

class HeartRate(db.Model):
    __tablename__ = 'heart_rate(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class RespRate(db.Model):
    __tablename__ = 'resp_rate(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)
    
class Temperature(db.Model):
    __tablename__ = 'temperature(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Spo2(db.Model):
    __tablename__ = 'spo2(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Spo2_old(db.Model):
    __tablename__ = 'spo2'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)
    
class Bp_mean(db.Model):
    __tablename__ = 'bp_mean(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Bp_mean_old(db.Model):
    __tablename__ = 'bp_mean'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Bp_sys(db.Model):
    __tablename__ = 'bp_sys(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Bp_sys_old(db.Model):
    __tablename__ = 'bp_sys'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Bp_dia(db.Model):
    __tablename__ = 'bp_dia(3)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)
    
class Bp_dia_old(db.Model):
    __tablename__ = 'bp_dia'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Mychoice(db.Model):
    __tablename__ = 'mychoice'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    suggestion = db.Column(db.Integer)
    choice = db.Column(db.Integer)
    choicetime = db.Column(db.DateTime)
    
class Mychoice_shock(db.Model):
    __tablename__ = 'mychoice_shock'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    suggestion = db.Column(db.Integer)
    choice = db.Column(db.Integer)
    choicetime = db.Column(db.DateTime)
    
class Mychoice_breath(db.Model):
    __tablename__ = 'mychoice_breath'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    suggestion = db.Column(db.Integer)
    choice = db.Column(db.Integer)
    choicetime = db.Column(db.DateTime)

class HeartRate_old(db.Model):
    __tablename__ = 'heart_rate'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class RespRate_old(db.Model):
    __tablename__ = 'resp_rate'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Integer)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)
    
class Temperature_old(db.Model):
    __tablename__ = 'temperature'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float)
    valueuom = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Integer)

class Calcium_old(db.Model):
    __tablename__ = 'calcium'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Albumin_old(db.Model):
    __tablename__ = 'albumin'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Hemoglobin_old(db.Model):
    __tablename__ = 'hemoglobin'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class WBC_old(db.Model):
    __tablename__ = 'wbc'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Glucose_old(db.Model):
    __tablename__ = 'glucose'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Chloride_old(db.Model):
    __tablename__ = 'chloride'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Potassium_old(db.Model):
    __tablename__ = 'potassium'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Sodium_old(db.Model):
    __tablename__ = 'sodium'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class InsulinCV_old(db.Model):
    __tablename__ = 'insulin_cv'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)

class PhenylephrineCV_old(db.Model):
    __tablename__ = 'phenylephrine_cv'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)

class Bilirubin_old(db.Model):
    __tablename__ = 'bilirubin'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class RBC_old(db.Model):
    __tablename__ = 'rbc'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Albumin_breath(db.Model):
    __tablename__ = 'albumin(7)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Bilirubin_breath(db.Model):
    __tablename__ = 'bilirubin(7)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Calcium_breath(db.Model):
    __tablename__ = 'calcium(7)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Glucose_breath(db.Model):
    __tablename__ = 'glucose(7)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Hemoglobin_breath(db.Model):
    __tablename__ = 'hemoglobin(7)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Mech_vent_breath(db.Model):
    __tablename__ = 'mech_vent(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    FIO2 = db.Column(db.Float, nullable=False)

class Albumin_shock(db.Model):
    __tablename__ = 'albumin(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Calcium_shock(db.Model):
    __tablename__ = 'calcium(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Glucose_shock(db.Model):
    __tablename__ = 'glucose(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class Hemoglobin_shock(db.Model):
    __tablename__ = 'hemoglobin(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class RBC_shock(db.Model):
    __tablename__ = 'rbc(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)
    
class WBC_shock(db.Model):
    __tablename__ = 'wbc(6)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer)
    charttime = db.Column(db.DateTime, primary_key=True)
    value = db.Column(db.Float, nullable=False)
    valueuom = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(2), nullable=False)

class Dextrose_shock(db.Model):
    __tablename__ = 'dextrose(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    
class Kcl_shock(db.Model):
    __tablename__ = 'kcl(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    
class Nacl_shock(db.Model):
    __tablename__ = 'nacl(4)'
    icustay_id = db.Column(db.Integer, primary_key=True)
    charttime = db.Column(db.DateTime, primary_key=True)
    amount = db.Column(db.Float, nullable=False)

# 设置的钙，白蛋白，血红蛋白，白细胞正常范围
NORMAL_RANGES = {
    'glucose': (70, 99),         # 单位mg/dL
    'chloride': (96, 106),       # 单位mEq/L
    'potassium': (3.5, 5.0),     # 单位mEq/L
    'sodium': (135, 145),        # 单位mEq/L
    'calcium': (8.6, 10.3),      # 单位mg/dL
    'albumin': (3.4, 5.4),       # 单位g/dL
    'hemoglobin': (13.5, 17.5),  # g/dL
    'wbc': (4.5, 11.0),          # 单位 x10^9/L
    'bilirubin': (0.3, 1.0)      # 单位mg/dL
}

def is_value_abnormal(value, normal_range):
    """判断数值是否在正常范围之外"""
    return not (normal_range[0] <= value <= normal_range[1])


@app.route('/')
def index():
    global icustay_id,current_virtual_time,emit_time_thread,thread_stop_event,time_rate,change_userid_flag
    current_virtual_time = datetime(2024, 1, 1, 0, 0, 0)
    time_rate = 1
    if emit_time_thread and emit_time_thread.is_alive():
        thread_stop_event.set()  # Signal the thread to stop
        emit_time_thread.join()  # Wait for the thread to actually stop
        thread_stop_event.clear()  # Clear the event for the next use
        print("Emit time thread terminated.")
    
    # Reset the stop event in case it was set previously
    thread_stop_event.clear()
    if change_userid_flag:
        change_userid_flag = False
    else:
        random_icustay = Age.query.order_by(func.random()).first()
        if random_icustay:
            icustay_id = random_icustay.icustay_id
            print(f"Random ICUSTAY_ID: {icustay_id}")
    
    emit_time_thread = threading.Thread(target=emit_time,args=(icustay_id,))
    emit_time_thread.daemon = True
    emit_time_thread.start()
    return render_template('index.html')

@app.route('/change_userid',methods=['POST'])
def change_userid():
    global icustay_id,current_virtual_time,emit_time_thread,thread_stop_event,time_rate,change_userid_flag
    data = request.json
    icustay_id_received = int(data['icustay_id'])
        # 查询数据库以检查icustay_id是否存在
    icustay_entry = Age.query.filter_by(icustay_id=icustay_id_received).first()
    if icustay_entry is None:
        # 如果icustay_id不存在，则返回错误消息
        return jsonify({"icustay_id_error": True})
    change_userid_flag = True
    icustay_id = icustay_id_received
    current_virtual_time = datetime(2024, 1, 1, 0, 0, 0)
    time_rate = 1
    if emit_time_thread and emit_time_thread.is_alive():
        thread_stop_event.set()  # Signal the thread to stop
        emit_time_thread.join()  # Wait for the thread to actually stop
        thread_stop_event.clear()  # Clear the event for the next use
        print("Emit time thread terminated.")
    
    # Reset the stop event in case it was set previously
    thread_stop_event.clear()
    emit_time_thread = threading.Thread(target=emit_time,args=(icustay_id,))
    emit_time_thread.daemon = True
    emit_time_thread.start()
    return jsonify({"message": "成功处理"})

@app.route('/get_patient_data',methods=['POST'])
def get_data():
    global icustay_id

    age = Age.query.filter_by(icustay_id=icustay_id).first() if icustay_id else None
    gender = Gender.query.filter_by(icustay_id=icustay_id).first() if icustay_id else None
    height = Height.query.filter_by(icustay_id=icustay_id).first() if icustay_id else None
    weight = Weight.query.filter_by(icustay_id=icustay_id).first() if icustay_id else None
    # 准备传递给模板的数据
    age_value = age.age if age else 'N/A'
    gender_value = gender.gender if gender else 'N/A'
    height_value = f"{height.value:.2f} cm" if height else 'N/A'
    weight_value = f"{weight.value:.2f} kg" if weight else 'N/A'
    underlying_conditions = UnderlyingCondition.query.filter_by(icustay_id=icustay_id).first()
    conditions_to_display = []
    if underlying_conditions:
        conditions_columns = UnderlyingCondition.__table__.columns.keys()
        for column in conditions_columns[1:]:
            if getattr(underlying_conditions, column) == 1:
                conditions_to_display.append(column.replace('_', ' ').capitalize())
    diagnosis_conditions = DiagnosisCondition.query.filter_by(icustay_id=icustay_id).all()
    diagnosis_to_display = []
    for d in diagnosis_conditions:
        D_Icd_Diagnoses_result = D_Icd_Diagnoses.query.filter_by(icd9_code = d.icd9_code).first()
        if D_Icd_Diagnoses_result:
            icd9_code = D_Icd_Diagnoses_result.long_title
        else:
            print("No ICD9 code found")
            print(d.seq_num)
            icd9_code = ("N/A") # 如果没有找到对应的icd9_code，则显示N/A。
        diagnosis_to_display.append({'seq_num': d.seq_num, 'icd9_code': icd9_code})
    data = {
        'icustay_id': icustay_id,
        'age': age_value,
        'gender': gender_value,
        'height': height_value,
        'weight': weight_value,
        'conditions_to_display': conditions_to_display,
        'diagnosis_to_display': diagnosis_to_display
    }
    return jsonify(data)

@app.route('/mychoice', methods=['POST'])
def receive_my_choice():
    global current_virtual_time,icustay_id
    data = request.json

    mychoice = data.get('mychoice')
    index = data.get('index')
    charttime = data.get('charttime')
    print(charttime)
    existing_choice = Mychoice.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
    if existing_choice:
        existing_choice.suggestion = index
        existing_choice.choice = mychoice
    else:
        new_choice = Mychoice(icustay_id=icustay_id, charttime=charttime, suggestion=index, choice=mychoice, choicetime=current_virtual_time)
        db.session.add(new_choice)
    db.session.commit()

    return jsonify({'message': 'Data received and stored successfully.'}), 200

@app.route('/mychoice_shock', methods=['POST'])
def receive_my_choice_shock():
    global current_virtual_time,icustay_id
    data = request.json

    mychoice = data.get('mychoice')
    index = data.get('index')
    charttime = data.get('charttime')
    print(charttime)
    existing_choice = Mychoice_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
    if existing_choice:
        existing_choice.suggestion = index
        existing_choice.choice = mychoice
    else:
        new_choice = Mychoice_shock(icustay_id=icustay_id, charttime=charttime, suggestion=index, choice=mychoice, choicetime=current_virtual_time)
        db.session.add(new_choice)
    db.session.commit()

    return jsonify({'message': 'Data received and stored successfully.'}), 200

@app.route('/mychoice_breath', methods=['POST'])
def receive_my_choice_breath():
    global current_virtual_time,icustay_id
    data = request.json

    mychoice = data.get('mychoice')
    index = data.get('index')
    charttime = data.get('charttime')
    print(charttime)
    existing_choice = Mychoice_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
    if existing_choice:
        existing_choice.suggestion = index
        existing_choice.choice = mychoice
    else:
        new_choice = Mychoice_breath(icustay_id=icustay_id, charttime=charttime, suggestion=index, choice=mychoice, choicetime=current_virtual_time)
        db.session.add(new_choice)
    db.session.commit()

    return jsonify({'message': 'Data received and stored successfully.'}), 200

@app.route("/refresh_icustay")
def refresh_icustay():
    session.pop('icustay_id', None)
    return "ICUSTAY_ID refreshed", 200

@socketio.on('connect')
def handle_connect():
    global connectioned
    connectioned = True
    print('Client connected')


@socketio.on('disconnect')
def handle_disconnect():
    global connectioned
    connectioned = False
    print('Client disconnected')

@socketio.on('update_time_rate')
def update_time_rate(data):
    global time_rate
    time_rate = data['multiplier']
    print(f'Time rate updated: {time_rate}')

def emit_time(icustay_id):
    global current_virtual_time,time_rate,socketio,connectioned,thread_stop_event
    heart_rate_record_last = 0
    bp_mean_record_last = 0
    spo2_record_last = 0
    while not thread_stop_event.is_set():
        while not connectioned: time.sleep(1)
        current_virtual_time += timedelta(seconds=1)
        formatted_time = current_virtual_time.strftime('%Y-%m-%d %H:%M:%S')
        print(f'Emitting time: {formatted_time}')
        socketio.emit('update_time', {'time': formatted_time})
        with app.app_context():

            heart_rate_record = HeartRate.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if heart_rate_record: 
                send_heart_rate(heart_rate_record.value)
                heart_rate_record_last = heart_rate_record.value
            else:
                send_spo2(heart_rate_record_last)
            spo2_record = Spo2.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if spo2_record: 
                send_spo2(spo2_record.value)
                spo2_record_last = spo2_record.value
            else:
                send_spo2(spo2_record_last)
            resp_rate_record = RespRate.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if resp_rate_record: send_resp_rate(resp_rate_record.value)
            temperature_record = Temperature.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if temperature_record: send_temperature(round(temperature_record.value, 1))
            bp_sys_record = Bp_sys.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if bp_sys_record: send_bp_sys(bp_sys_record.value)
            bp_dia_record = Bp_dia.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if bp_dia_record: send_bp_dia(bp_dia_record.value)
            bp_mean_record = Bp_mean.query.filter_by(icustay_id=icustay_id, charttime=current_virtual_time).first()
            if bp_mean_record: 
                send_bp_mean(bp_mean_record.value)
                bp_mean_record_last = bp_mean_record.value
            else: send_bp_mean(bp_mean_record_last)
            emit_blood_sugar(current_virtual_time, icustay_id)
            emit_shock(current_virtual_time, icustay_id)
            emit_breath(current_virtual_time, icustay_id)
        time.sleep(1/time_rate)
        
heart_rate_queue = deque(maxlen=60)
spo2_queue = deque(maxlen=60)
bp_queue = deque(maxlen=60)
bloodsuger_queue = deque()
breath_queue = deque()
shock_queue = deque()
def send_heart_rate(value):
    global heart_rate_queue
    while len(heart_rate_queue) < 60:
        heart_rate_queue.append(-1)
    heart_rate_queue.append(value)
    socketio.emit('heart_rate', {'heart_rate': value})  # 发送心电图数据
def send_spo2(value):
    global spo2_queue
    while len(spo2_queue) < 60:
        spo2_queue.append(-1)
    spo2_queue.append(value)
    socketio.emit('spo2', {'spo2': value})  # 发送心电图数据
def send_resp_rate(value):
    socketio.emit('resp_rate', {'resp_rate': value})  # 发送心电图数据
def send_temperature(value):
    socketio.emit('temperature', {'temperature': value})  # 发送心电图数据
def send_bp_sys(value):
    socketio.emit('bp_sys', {'bp_sys': value})
def send_bp_dia(value):
    socketio.emit('bp_dia', {'bp_dia': value})
def send_bp_mean(value):
    global bp_queue
    while len(bp_queue) < 60:
        bp_queue.append(-1)
    bp_queue.append(value)
    socketio.emit('bp_mean', {'bp_mean': value})

@app.route('/get_initial_heart_rate_data', methods=['POST'])
def get_initial_heart_rate_data():
    global heart_rate_queue, spo2_queue, bp_queue
    return jsonify(list(heart_rate_queue))

@app.route('/get_initial_spo2_data', methods=['POST'])
def get_initial_spo2_data():
    global spo2_queue
    return jsonify(list(spo2_queue))

@app.route('/get_initial_bp_data', methods=['POST'])
def get_initial_bp_data():
    global bp_queue
    return jsonify(list(bp_queue))

@app.route('/get_initial_bloodsuger_data', methods=['POST'])
def get_initial_bloodsuger_data():
    global bloodsuger_queue
    return jsonify(list(bloodsuger_queue))

@app.route('/get_initial_shock_data', methods=['POST'])
def get_initial_shock_data():
    global shock_queue
    return jsonify(list(shock_queue))

@app.route('/get_initial_breath_data', methods=['POST'])
def get_initial_breath_data():
    global breath_queue
    return jsonify(list(breath_queue))

def emit_blood_sugar(charttime, icustay_id):
    global bloodsuger_queue
    suggestions_insulin = ''
    suggestions_phenylephrine = ''
    with app.app_context():
        glucose_record = Glucose.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        calcium_record = Calcium.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        chloride_record = Chloride.query.filter_by(icustay_id=icustay_id,charttime=charttime).first() if charttime else None
        potassium_record = Potassium.query.filter_by(icustay_id=icustay_id,charttime=charttime).first() if charttime else None
        sodium_record = Sodium.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        albumin_record = Albumin.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        hemoglobin_record = Hemoglobin.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        wbc_record = WBC.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        if all(v is None for v in [glucose_record, calcium_record, chloride_record, potassium_record, sodium_record, albumin_record, hemoglobin_record, wbc_record]):
            return
        # 根据是否超出正常范围判断异常情况
        glucose_abnormal = is_value_abnormal(glucose_record.value, NORMAL_RANGES['glucose']) if glucose_record else False
        chloride_abnormal = is_value_abnormal(chloride_record.value,NORMAL_RANGES['chloride']) if chloride_record else False
        potassium_abnormal = is_value_abnormal(potassium_record.value,NORMAL_RANGES['potassium']) if potassium_record else False
        sodium_abnormal = is_value_abnormal(sodium_record.value, NORMAL_RANGES['sodium']) if sodium_record else False
        calcium_abnormal = is_value_abnormal(calcium_record.value, NORMAL_RANGES['calcium']) if calcium_record else False
        albumin_abnormal = is_value_abnormal(albumin_record.value, NORMAL_RANGES['albumin']) if albumin_record else False
        hemoglobin_abnormal = is_value_abnormal(hemoglobin_record.value, NORMAL_RANGES['hemoglobin']) if hemoglobin_record else False
        wbc_abnormal = is_value_abnormal(wbc_record.value, NORMAL_RANGES['wbc']) if wbc_record else False

        if charttime:
            insulin_record = InsulinCV.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            phenylephrine_record = PhenylephrineCV.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            # 创建虚拟数据
            # engine = create_engine(f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4")
            # Session = sessionmaker(bind=engine)
            # session2 = Session()
            # if randint(0,1000)%2 == 0:
            #     InsulinCV_record = InsulinCV(icustay_id=icustay_id, charttime=charttime, amount=randint(1,10))
            #     session2.add(InsulinCV_record)
            #     if randint(0,1000)%3 == 0:
            #         PhenylephrineCV_record = PhenylephrineCV(icustay_id=icustay_id, charttime=charttime, amount=randint(1,30))
            #         session2.add(PhenylephrineCV_record)
            # else:
            #     PhenylephrineCV_record = PhenylephrineCV(icustay_id=icustay_id, charttime=charttime, amount=randint(1,30))
            #     session2.add(PhenylephrineCV_record)
            # session2.commit()
            if insulin_record:
                suggestions_insulin += f"注射 Insulin CV {insulin_record.amount} U "
            if phenylephrine_record:
                suggestions_phenylephrine += (f"注射 Phenylephrine CV {phenylephrine_record.amount} mg")
        dataSets = {}
        items = [
            {'name': '血糖', 'value': glucose_record.value if glucose_record else None, 'unit': 'mg/dL', 'abnormal': glucose_abnormal,'normalRange':NORMAL_RANGES['glucose']},
            {'name': '氯离子', 'value': chloride_record.value if chloride_record else None, 'unit': 'mEq/L', 'abnormal': chloride_abnormal,'normalRange':NORMAL_RANGES['chloride']},
            {'name': '钾', 'value': potassium_record.value if potassium_record else None, 'unit': 'mEq/L', 'abnormal': potassium_abnormal,'normalRange':NORMAL_RANGES['potassium']},
            {'name': '纳', 'value': sodium_record.value if sodium_record else None, 'unit': 'mEq/L', 'abnormal': sodium_abnormal,'normalRange':NORMAL_RANGES['sodium']},
            {'name': '血红蛋白', 'value': hemoglobin_record.value if hemoglobin_record else None, 'unit': 'g/dl', 'abnormal': hemoglobin_abnormal,'normalRange':NORMAL_RANGES['hemoglobin']},
            {'name': '钙', 'value': calcium_record.value if calcium_record else None, 'unit': 'mmol/L', 'abnormal': calcium_abnormal,'normalRange':NORMAL_RANGES['calcium']},
            {'name': '白蛋白', 'value': albumin_record.value if albumin_record else None, 'unit': 'mmol/L', 'abnormal': albumin_abnormal,'normalRange':NORMAL_RANGES['albumin']},
            {'name': '白细胞', 'value': wbc_record.value if wbc_record else None, 'unit': 'mmol/L', 'abnormal': wbc_abnormal,'normalRange':NORMAL_RANGES['wbc']},
        ]
        items_new = [item for item in items if item['value'] is not None]
        dataSets['items'] = items_new
        formatted_time = charttime.strftime('%Y-%m-%d %H:%M:%S')
        dataSets['charttime'] = formatted_time
        dataSets['suggestions_insulin'] = suggestions_insulin
        dataSets['suggestions_phenylephrine'] = suggestions_phenylephrine
        socketio.emit('laboratory_results', dataSets)
        bloodsuger_queue.append(dataSets)
    return

def emit_shock(charttime, icustay_id):
    global shock_queue
    suggestions_dextrose = ''
    suggestions_kcl = ''
    suggestions_nacl = ''
    with app.app_context():
        glucose_record = Glucose_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        calcium_record = Calcium_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        albumin_record = Albumin_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        hemoglobin_record = Hemoglobin_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        wbc_record = WBC_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        if all(v is None for v in [glucose_record, calcium_record, albumin_record, hemoglobin_record, wbc_record]):
            return
        # 根据是否超出正常范围判断异常情况
        glucose_abnormal = is_value_abnormal(glucose_record.value, NORMAL_RANGES['glucose']) if glucose_record else False
        calcium_abnormal = is_value_abnormal(calcium_record.value, NORMAL_RANGES['calcium']) if calcium_record else False
        albumin_abnormal = is_value_abnormal(albumin_record.value, NORMAL_RANGES['albumin']) if albumin_record else False
        hemoglobin_abnormal = is_value_abnormal(hemoglobin_record.value, NORMAL_RANGES['hemoglobin']) if hemoglobin_record else False
        wbc_abnormal = is_value_abnormal(wbc_record.value, NORMAL_RANGES['wbc']) if wbc_record else False

        if charttime:
            dextrose_record = Dextrose_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            kcl_record = Kcl_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            nacl_record = Nacl_shock.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            if not (dextrose_record and kcl_record and nacl_record):
                # 创建虚拟数据
                engine = create_engine(f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4")
                Session = sessionmaker(bind=engine)
                session2 = Session()
                myflag = True
                if randint(0,1000)%2 == 0:
                    possible_numbers = [50, 100, 125, 250, 500, 750, 1000]
                    dextrose_shock_record = Dextrose_shock(icustay_id=icustay_id, charttime=charttime, amount=random.choice(possible_numbers))
                    session2.add(dextrose_shock_record)
                    suggestions_dextrose += f"注射 dextrose {dextrose_shock_record.amount} ml"
                    myflag = False
                if randint(0,1000)%2 == 0:
                    possible_numbers = [2, 3, 4, 20, 40]
                    kcl_shock_record = Kcl_shock(icustay_id=icustay_id, charttime=charttime, amount=random.choice(possible_numbers))
                    session2.add(kcl_shock_record)
                    suggestions_kcl += (f"注射 kcl {kcl_shock_record.amount} mEq")
                    myflag = False
                if myflag or randint(0,1000)%2 == 0:
                    possible_numbers = [5, 10, 20, 40, 100, 150]
                    nacl_shock_record = Nacl_shock(icustay_id=icustay_id, charttime=charttime, amount=random.choice(possible_numbers))
                    session2.add(nacl_shock_record)
                    suggestions_nacl += (f"注射 nacl {nacl_shock_record.amount} ml")
                session2.commit()
            else:
                if dextrose_record:
                    suggestions_dextrose += f"注射 dextrose {dextrose_record.amount} ml"
                if kcl_record:
                    suggestions_kcl += (f"注射 kcl {kcl_record.amount} mEq")
                if nacl_record:
                    suggestions_nacl += (f"注射 nacl {kcl_record.amount} ml")
        dataSets = {}
        items = [
            {'name': '血糖', 'value': glucose_record.value if glucose_record else None, 'unit': 'mg/dL', 'abnormal': glucose_abnormal,'normalRange':NORMAL_RANGES['glucose']},
            {'name': '血红蛋白', 'value': hemoglobin_record.value if hemoglobin_record else None, 'unit': 'mg/dL', 'abnormal': hemoglobin_abnormal,'normalRange':NORMAL_RANGES['hemoglobin']},
            {'name': '钙', 'value': calcium_record.value if calcium_record else None, 'unit': 'mmol/L', 'abnormal': calcium_abnormal,'normalRange':NORMAL_RANGES['calcium']},
            {'name': '白蛋白', 'value': albumin_record.value if albumin_record else None, 'unit': 'mmol/L', 'abnormal': albumin_abnormal,'normalRange':NORMAL_RANGES['albumin']},
            {'name': '白细胞', 'value': wbc_record.value if wbc_record else None, 'unit': 'mmol/L', 'abnormal': wbc_abnormal,'normalRange':NORMAL_RANGES['wbc']},
        ]
        items_new = [item for item in items if item['value'] is not None]
        dataSets['items'] = items_new
        formatted_time = charttime.strftime('%Y-%m-%d %H:%M:%S')
        dataSets['charttime'] = formatted_time
        dataSets['suggestions_dextrose'] = suggestions_dextrose
        dataSets['suggestions_kcl'] = suggestions_kcl
        dataSets['suggestions_nacl'] = suggestions_nacl
        socketio.emit('laboratory_results_shock', dataSets)
        shock_queue.append(dataSets)
    return

def emit_breath(charttime, icustay_id):
    global breath_queue
    suggestions_mech_vent = ''
    with app.app_context():
        glucose_record = Glucose_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        calcium_record = Calcium_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        bilirubin_record = Bilirubin_breath.query.filter_by(icustay_id=icustay_id,charttime=charttime).first() if charttime else None
        albumin_record = Albumin_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        hemoglobin_record = Hemoglobin_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first() if charttime else None
        if all(v is None for v in [glucose_record, calcium_record, bilirubin_record, albumin_record, hemoglobin_record]):
            return
        # 根据是否超出正常范围判断异常情况
        glucose_abnormal = is_value_abnormal(glucose_record.value, NORMAL_RANGES['glucose']) if glucose_record else False
        bilirubin_abnormal = is_value_abnormal(bilirubin_record.value,NORMAL_RANGES['potassium']) if bilirubin_record else False
        calcium_abnormal = is_value_abnormal(calcium_record.value, NORMAL_RANGES['calcium']) if calcium_record else False
        albumin_abnormal = is_value_abnormal(albumin_record.value, NORMAL_RANGES['albumin']) if albumin_record else False
        hemoglobin_abnormal = is_value_abnormal(hemoglobin_record.value, NORMAL_RANGES['hemoglobin']) if hemoglobin_record else False

        if charttime:
            mech_vent_record = Mech_vent_breath.query.filter_by(icustay_id=icustay_id, charttime=charttime).first()
            if not mech_vent_record:
                # 创建虚拟数据
                engine = create_engine(f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4")
                Session = sessionmaker(bind=engine)
                session2 = Session()
                possible_numbers = [40, 50, 60, 70, 80, 90, 100]
                mech_vent_breath_record = Mech_vent_breath(icustay_id=icustay_id, charttime=charttime, FIO2=random.choice(possible_numbers))
                session2.add(mech_vent_breath_record)
                session2.commit()
                suggestions_mech_vent += f"进行 mech_vent {mech_vent_breath_record.FIO2} "
            else:
                suggestions_mech_vent += f"进行 mech_vent {mech_vent_record.FIO2} "

        dataSets = {}
        items = [
            {'name': '血糖', 'value': glucose_record.value if glucose_record else None, 'unit': 'mg/dL', 'abnormal': glucose_abnormal,'normalRange':NORMAL_RANGES['glucose']},
            {'name': '胆红素', 'value': bilirubin_record.value if bilirubin_record else None, 'unit': 'mEq/L', 'abnormal': bilirubin_abnormal,'normalRange':NORMAL_RANGES['potassium']},
            {'name': '血红蛋白', 'value': hemoglobin_record.value if hemoglobin_record else None, 'unit': 'g/dl', 'abnormal': hemoglobin_abnormal,'normalRange':NORMAL_RANGES['hemoglobin']},
            {'name': '钙', 'value': calcium_record.value if calcium_record else None, 'unit': 'mmol/L', 'abnormal': calcium_abnormal,'normalRange':NORMAL_RANGES['calcium']},
            {'name': '白蛋白', 'value': albumin_record.value if albumin_record else None, 'unit': 'mmol/L', 'abnormal': albumin_abnormal,'normalRange':NORMAL_RANGES['albumin']},
        ]
        items_new = [item for item in items if item['value'] is not None]
        dataSets['items'] = items_new
        formatted_time = charttime.strftime('%Y-%m-%d %H:%M:%S')
        dataSets['charttime'] = formatted_time
        dataSets['suggestions_mech_vent'] = suggestions_mech_vent
        socketio.emit('laboratory_results_breath', dataSets)
        breath_queue.append(dataSets)
    return

if __name__ == '__main__':
    socketio.run(app, allow_unsafe_werkzeug=True)
