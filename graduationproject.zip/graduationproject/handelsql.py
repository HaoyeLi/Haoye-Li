from datetime import datetime, timedelta
from random import randint
import random
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app import WBC, Albumin, Albumin_old, Bp_dia, Bp_dia_old, Bp_mean, Bp_mean_old, Bp_sys, Bp_sys_old, Calcium, Calcium_old, Chloride, Chloride_old, Glucose, Glucose_old, HeartRate, HeartRate_old, Hemoglobin, Hemoglobin_old, Potassium, Potassium_old, RespRate_old, Sodium, Sodium_old, Temperature_old, WBC_old, db, Spo2,Temperature,RespRate, app  # your_module 应该是你的数据库模型所在的模块
from sqlalchemy.sql.expression import func

HOSTNAME = "127.0.0.1"
PORT = 3306
USERNAME = "root"
PASSWORD = "lsjhahayywd"
DATABASE = "bloodsugar"
# 创建数据库引擎
engine = create_engine(f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4")
Session = sessionmaker(bind=engine)
session = Session()
icustay_id = 216543
def runheartrate():
    # 定义插入数据的参数
    itemid = 211
    valueuom = "BPM"
    error = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        # 计算当前时间
        current_time = start_time + timedelta(seconds=i)
        value = randint(90, 100)
        heart_rate_data = HeartRate(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, error=error)
        session.add(heart_rate_data)
    session.commit()
def runSpo2():
    # 定义插入数据的参数

    itemid = 211
    valueuom = "BPM"
    error = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        if (randint(0,100)%3==0):
            # 计算当前时间
            current_time = start_time + timedelta(seconds=i)
            value = randint(90, 100)
            heart_rate_data = Spo2(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, error=error)
            session.add(heart_rate_data)
    session.commit()
def runTemperature():
    # 定义插入数据的参数
    itemid = 211
    valueuom = "BPM"
    error = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        if (randint(0,100)%3==0):
            # 计算当前时间
            current_time = start_time + timedelta(seconds=i)
            # 生成指定范围内的小数
            random_float = random.uniform(36.0, 38.0)

            # 保留一位小数
            value = round(random_float, 1)
            heart_rate_data = Temperature(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, error=error)
            session.add(heart_rate_data)
    session.commit()
def runRespRate():
    # 定义插入数据的参数
    itemid = 211
    valueuom = "BPM"
    error = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        if (randint(0,100)%3==0):
            # 计算当前时间
            current_time = start_time + timedelta(seconds=i)
            value = randint(15, 18)
            heart_rate_data = RespRate(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, error=error)
            session.add(heart_rate_data)
    session.commit()
# 设置的钙，白蛋白，血红蛋白，白细胞正常范围
NORMAL_RANGES = {
    'glucose': (70.0, 99.0),         # 单位mg/dL
    'chloride': (96.0, 106.0),       # 单位mEq/L
    'potassium': (3.5, 5.0),     # 单位mEq/L
    'sodium': (135.0, 145.0),        # 单位mEq/L
    'calcium': (8.6, 10.3),      # 单位mg/dL
    'albumin': (3.4, 5.4),       # 单位g/dL
    'hemoglobin': (13.5, 17.5),  # g/dL
    'wbc': (4.5, 11.0),          # 单位 x10^9/L
}
def runbloodsuger():
    # 定义插入数据的参数
    itemid = 211
    source = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        if (randint(0,1000)%20==0):
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["glucose"][1] - NORMAL_RANGES["glucose"][0])/10
                random_float = random.uniform(NORMAL_RANGES["glucose"][0]-errornum, NORMAL_RANGES["glucose"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "mg/dL"
                glucose_record = Glucose(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(glucose_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["calcium"][1] - NORMAL_RANGES["calcium"][0])/10
                random_float = random.uniform(NORMAL_RANGES["calcium"][0]-errornum, NORMAL_RANGES["calcium"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "mg/dL"
                calcium_record = Calcium(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(calcium_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["chloride"][1] - NORMAL_RANGES["chloride"][0])/10
                random_float = random.uniform(NORMAL_RANGES["chloride"][0]-errornum, NORMAL_RANGES["chloride"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "mEq/L"
                chloride_record = Chloride(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(chloride_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["potassium"][1] - NORMAL_RANGES["potassium"][0])/10
                random_float = random.uniform(NORMAL_RANGES["potassium"][0]-errornum, NORMAL_RANGES["potassium"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "mEq/L"
                potassium_record = Potassium(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(potassium_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["sodium"][1] - NORMAL_RANGES["sodium"][0])/10
                random_float = random.uniform(NORMAL_RANGES["sodium"][0]-errornum, NORMAL_RANGES["sodium"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "mg/dL"
                sodium_record = Sodium(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(sodium_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["albumin"][1] - NORMAL_RANGES["albumin"][0])/10
                random_float = random.uniform(NORMAL_RANGES["albumin"][0]-errornum, NORMAL_RANGES["albumin"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "g/dL"
                albumin_record = Albumin(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(albumin_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["hemoglobin"][1] - NORMAL_RANGES["hemoglobin"][0])/10
                random_float = random.uniform(NORMAL_RANGES["hemoglobin"][0]-errornum, NORMAL_RANGES["hemoglobin"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "g/dl"
                hemoglobin_record = Hemoglobin(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(hemoglobin_record)
            if (randint(0,100)%2==0):
                # 计算当前时间
                current_time = start_time + timedelta(seconds=i)
                errornum = (NORMAL_RANGES["wbc"][1] - NORMAL_RANGES["wbc"][0])/10
                random_float = random.uniform(NORMAL_RANGES["wbc"][0]-errornum, NORMAL_RANGES["wbc"][1]+errornum)
                value = round(random_float, 1)
                valueuom = "K/uL"
                wbc_record = WBC(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=value, valueuom=valueuom, source=source)
                session.add(wbc_record)

    session.commit()
def runbp():
    # 定义插入数据的参数
    itemid = 211
    valueuom = "BPM"
    error = None
    start_time = datetime(2024, 1, 1, 0, 0, 0)

    # 插入1000条数据
    for i in range(1000):
        if (randint(0,100)%3==0):
            # 计算当前时间
            current_time = start_time + timedelta(seconds=i)
            valuesys = randint(90, 120)
            valuedia = randint(40, 70)
            valuemean = int((valuesys + valuedia) / 2)
            bp_sys_data = Bp_sys(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=valuesys, valueuom=valueuom, error=error)
            bp_dia_data = Bp_dia(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=valuedia, valueuom=valueuom, error=error)
            bp_mean_data = Bp_mean(icustay_id=icustay_id, itemid=itemid, charttime=current_time, value=valuemean, valueuom=valueuom, error=error)
            session.add(bp_sys_data)
            session.add(bp_dia_data)
            session.add(bp_mean_data)
    session.commit()

if __name__ == "__main__":
    with app.app_context():
        # HeartRate
        HeartRate_old_values = HeartRate_old.query.with_entities(HeartRate_old.value).all()
        HeartRate_rows = HeartRate.query.all()
        for i, HeartRate_row in enumerate(HeartRate_rows):
            HeartRate_row.value = HeartRate_old_values[i][0]
        # # Temperature
        # temperature_old_values = Temperature_old.query.with_entities(Temperature_old.value).all()
        # temperature_rows = Temperature.query.all()
        # for i, temperature_row in enumerate(temperature_rows):
        #     temperature_row.value = temperature_old_values[i][0]

        # # RespRate
        # resprate_old_values = RespRate_old.query.with_entities(RespRate_old.value).all()
        # resprate_rows = RespRate.query.all()
        # for i, resprate_row in enumerate(resprate_rows):
        #     resprate_row.value = resprate_old_values[i][0]

        # # Glucose
        # glucose_old_values = Glucose_old.query.with_entities(Glucose_old.value).all()
        # glucose_rows = Glucose.query.all()
        # for i, glucose_row in enumerate(glucose_rows):
        #     glucose_row.value = glucose_old_values[i][0]

        # # Calcium
        # calcium_old_values = Calcium_old.query.with_entities(Calcium_old.value).all()
        # calcium_rows = Calcium.query.all()
        # for i, calcium_row in enumerate(calcium_rows):
        #     calcium_row.value = calcium_old_values[i][0]

        # # Chloride
        # chloride_old_values = Chloride_old.query.with_entities(Chloride_old.value).all()
        # chloride_rows = Chloride.query.all()
        # for i, chloride_row in enumerate(chloride_rows):
        #     chloride_row.value = chloride_old_values[i][0]

        # # Potassium
        # potassium_old_values = Potassium_old.query.with_entities(Potassium_old.value).all()
        # potassium_rows = Potassium.query.all()
        # for i, potassium_row in enumerate(potassium_rows):
        #     potassium_row.value = potassium_old_values[i][0]

        # # Sodium
        # sodium_old_values = Sodium_old.query.with_entities(Sodium_old.value).all()
        # sodium_rows = Sodium.query.all()
        # for i, sodium_row in enumerate(sodium_rows):
        #     sodium_row.value = sodium_old_values[i][0]

        # # Albumin
        # albumin_old_values = Albumin_old.query.with_entities(Albumin_old.value).all()
        # albumin_rows = Albumin.query.all()
        # for i, albumin_row in enumerate(albumin_rows):
        #     albumin_row.value = albumin_old_values[i][0]

        # # Hemoglobin
        # hemoglobin_old_values = Hemoglobin_old.query.with_entities(Hemoglobin_old.value).all()
        # hemoglobin_rows = Hemoglobin.query.all()
        # for i, hemoglobin_row in enumerate(hemoglobin_rows):
        #     hemoglobin_row.value = hemoglobin_old_values[i][0]

        # # WBC
        # wbc_old_values = WBC_old.query.with_entities(WBC_old.value).all()
        # wbc_rows = WBC.query.all()
        # for i, wbc_row in enumerate(wbc_rows):
        #     wbc_row.value = wbc_old_values[i][0]

        # # Bp_sys
        # bp_sys_old_values = Bp_sys_old.query.with_entities(Bp_sys_old.value).all()
        # bp_sys_rows = Bp_sys.query.all()
        # for i, bp_sys_row in enumerate(bp_sys_rows):
        #     bp_sys_row.value = bp_sys_old_values[i][0]

        # # Bp_dia
        # bp_dia_old_values = Bp_dia_old.query.with_entities(Bp_dia_old.value).all()
        # bp_dia_rows = Bp_dia.query.all()
        # for i, bp_dia_row in enumerate(bp_dia_rows):
        #     bp_dia_row.value = bp_dia_old_values[i][0]

        # # Bp_mean
        # bp_mean_old_values = Bp_mean_old.query.with_entities(Bp_mean_old.value).all()
        # bp_mean_rows = Bp_mean.query.all()
        # for i, bp_mean_row in enumerate(bp_mean_rows):
        #     bp_mean_row.value = bp_mean_old_values[i][0]
        # db.session.commit()